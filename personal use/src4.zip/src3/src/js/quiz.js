const quizzes = {
  coldwave: [
    {
      question: "한파 시 집 안에서 가장 중요한 대처 방법은?",
      options: ["난방기구 끄기", "창문 열어 환기", "틈새 막기", "물을 마시지 않기"],
      answer: 2,
    },
    {
      question: "한파 경보 시 외출 시 가장 적절한 복장은?",
      options: ["얇은 옷 여러 겹", "단일 두꺼운 옷", "장갑과 모자 없이 가볍게", "운동복"],
      answer: 0,
    },
  ],
  heavysnow: [
    {
      question: "폭설이 내릴 때 운전 시 가장 중요한 준비물은?",
      options: ["여분의 연료", "스노우 체인", "비상약", "스마트폰"],
      answer: 1,
    },
    {
      question: "폭설 시 외출이 불가피할 경우 가장 적절한 행동은?",
      options: ["가볍게 뛰기", "천천히 걸으며 넘어지지 않기", "도로 한가운데로 걷기", "얼음 위로 걷기"],
      answer: 1,
    },
  ],
  snowaccidents: [
    {
      question: "눈길에 미끄러졌을 때 가장 먼저 해야 할 일은?",
      options: ["일어서기", "걷기 연습", "도움 요청", "물기를 닦고 상처 확인"],
      answer: 3,
    },
    {
      question: "눈길에서 미끄러지지 않기 위한 최선의 신발은?",
      options: ["밑창이 매끄러운 신발", "스니커즈", "미끄럼 방지 신발", "샌들"],
      answer: 2,
    },
  ],
  winterhike: [
    {
      question: "겨울철 산행을 계획할 때 가장 먼저 확인해야 할 사항은 무엇인가요?",
      options: ["산행 경로의 명소 위치", "날씨와 기온 예보", "산행 동반자의 체력 수준", "산행 후 맛집 정보"],
      answer: 1,
    },
    {
      question: "겨울 산행 시 적절한 복장으로 가장 중요한 것은 무엇일까요?",
      options: ["통풍이 잘되는 얇은 여름옷", "보온성이 높은 겹겹이 착용 가능한 옷", "무거운 옷 한 벌만 입는다.", "스타일이 좋은 옷을 선택한다."],
      answer: 1,
    },
    {
      question: "겨울 산행 중 저체온증이 의심될 때 가장 먼저 해야 할 일은 무엇일까요?",
      options: ["그대로 계속 산행을 이어간다.", "환자를 따뜻한 곳으로 옮기고 보온을 강화한다.", "눈을 녹여 마시도록 한다.", "주변에 도움을 요청하지 않는다."],
      answer: 1,
    },
    {
      question: "겨울 산행 중 눈길에서 미끄럼 사고를 예방하려면 가장 적절한 방법은 무엇인가요?",
      options: ["빠르게 걸어서 추위를 이긴다.", "아이젠이나 스패츠를 착용한다.", "하산할 때 가급적 뛰어내린다.", "손을 주머니에 넣고 걷는다."],
      answer: 1,
    },
    {
      question: "겨울 산행 전 필수로 준비해야 할 물품으로 적합하지 않은 것은 무엇일까요?",
      options: ["등산용 스틱", "충분한 물과 간식", "보온병에 담은 따뜻한 음료", "여름용 얇은 모자"],
      answer: 3,
    },
    {
      question: "겨울 산행 중 길을 잃었을 때 가장 올바른 행동은 무엇인가요?",
      options: ["산속에서 계속 이동해 빠져나온다.", "안전한 장소에서 구조를 요청하고 기다린다.", "도움을 요청하지 않고 스스로 해결하려 한다.", "체온 보호를 무시한다."],
      answer: 1,
    },
  ],
};

let currentQuiz = [];
let questionIndex = 0;
let score = 0;

// 퀴즈 주제 선택 및 랜덤화
function selectQuiz(quizName) {
  currentQuiz = quizzes[quizName];
  questionIndex = 0;
  score = 0; // 점수 초기화
  shuffleArray(currentQuiz); // 퀴즈를 랜덤 순서로 섞음
  displayQuestion();
}

// 질문 표시
function displayQuestion() {
  if (!currentQuiz || currentQuiz.length === 0) {
    alert("퀴즈 데이터가 없습니다.");
    return;
  }

  if (questionIndex >= currentQuiz.length) {
    displayScore(); // 모든 문제를 푼 후 점수 표시
    return;
  }

  const quiz = currentQuiz[questionIndex];
  document.getElementById("quizQuestion").textContent = quiz.question;
  const options = document.querySelectorAll(".option-btn");
  options.forEach((button, index) => {
    button.textContent = quiz.options[index];
    button.disabled = false; // 선택 버튼 활성화
  });
}

// 정답 선택
function selectAnswer(selectedIndex) {
  const quiz = currentQuiz[questionIndex];
  const options = document.querySelectorAll(".option-btn");

  // 버튼 비활성화로 중복 선택 방지
  options.forEach((button) => (button.disabled = true));

  if (selectedIndex === quiz.answer) {
    score++; // 정답이면 점수 증가
    alert("정답입니다!");
  } else {
    alert(`틀렸습니다. 정답은 "${quiz.options[quiz.answer]}"입니다.`);
  }
}

// 다음 질문
function nextQuestion() {
  questionIndex++;
  displayQuestion();
}

// 점수 표시
function displayScore() {
  const totalQuestions = currentQuiz.length;
  alert(`퀴즈 완료! 점수: ${score}/${totalQuestions} (${((score / totalQuestions) * 100).toFixed(2)}%)`);
}

// 배열을 랜덤으로 섞는 함수
function shuffleArray(array) {
  for (let i = array.length - 1; i > 0; i--) {
    const randomIndex = Math.floor(Math.random() * (i + 1));
    [array[i], array[randomIndex]] = [array[randomIndex], array[i]]; // 요소 위치를 교환
  }
}

// 첫 번째 질문 표시 (기본 설정)
window.onload = () => selectQuiz("winterhike"); // 기본 퀴즈를 설정
